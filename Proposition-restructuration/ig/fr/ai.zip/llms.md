# ans.fhir.fr.cds#2.0.1: Cercle De Soins(fr)

## Pages

* [Accueil](index.md)
* [Specifications](specifications.md)
* [Synthèse](spe_synthese.md)
* [Téléchargements et usages](downloads.md)
* [CDS Consommateur - XML Representation](ActorDefinition-CDS-Consommateur-Actor.xml.md)
* [CDS Créateur](ActorDefinition-CDS-Createur-Actor.md)
* [CDS Créateur](ActorDefinition-CDS-Createur-Actor-testing.md)
* [Mise à jour du cercle de soins](spe_mise_jour_cercle_soins.md)
* [Création du cercle de soins](spe_creation_cercle_soins.md)
* [CDS Consommateur - JSON Representation](ActorDefinition-CDS-Consommateur-Actor.json.md)
* [Annexes](annexes.md)
* [CDS Consommateur](ActorDefinition-CDS-Consommateur-Actor.ai.md)
* [CDS Gestionnaire - TTL Representation](ActorDefinition-CDS-Gestionnaire-Actor.ttl.md)
* [Tests](tests.md)
* [CDS Gestionnaire - XML Representation](ActorDefinition-CDS-Gestionnaire-Actor.xml.md)
* [CDS Gestionnaire](ActorDefinition-CDS-Gestionnaire-Actor.md)
* [CDS Créateur](ActorDefinition-CDS-Createur-Actor.ai.md)
* [](ActorDefinition-CDS-Gestionnaire-Actor.change.history.md)
* [CDS Consommateur](ActorDefinition-CDS-Consommateur-Actor.md)
* [CDS Gestionnaire - JSON Representation](ActorDefinition-CDS-Gestionnaire-Actor.json.md)
* [CDS Consommateur](ActorDefinition-CDS-Consommateur-Actor-testing.md)
* [CDS Consommateur - TTL Representation](ActorDefinition-CDS-Consommateur-Actor.ttl.md)
* [CDS Créateur - TTL Representation](ActorDefinition-CDS-Createur-Actor.ttl.md)
* [CDS Créateur - JSON Representation](ActorDefinition-CDS-Createur-Actor.json.md)
* [Historique](changes.md)
* [](ActorDefinition-CDS-Createur-Actor.change.history.md)
* [Informations sur la traduction](translationinfo.md)
* [CDS Gestionnaire](ActorDefinition-CDS-Gestionnaire-Actor-testing.md)
* [Consultation du cercle de soins](spe_consultation_cercle_soins.md)
* [CDS Créateur - XML Representation](ActorDefinition-CDS-Createur-Actor.xml.md)
* [](ActorDefinition-CDS-Consommateur-Actor.change.history.md)
* [CDS Gestionnaire](ActorDefinition-CDS-Gestionnaire-Actor.ai.md)
* [Résumé des artefacts](artifacts.md)

## Resources

### ValueSets

* [Roles des participants dans un cercle de soins](ValueSet-careteam-roles-vs.md)

### Logicals

* [CDS Cercle Soins](StructureDefinition-cds-cercle-soins.md)
* [CDS Contact](StructureDefinition-cds-contact.md)
* [CDS Entite Geographique](StructureDefinition-cds-entite-geographique.md)
* [CDS Entite Juridique](StructureDefinition-cds-entite-juridique.md)
* [CDS Exercice Professionnel](StructureDefinition-cds-exercice-professionnel.md)
* [CDS Membre Cercle Soins](StructureDefinition-cds-membre-cercle-soins.md)
* [CDS Organisation Interne](StructureDefinition-cds-organisation-interne.md)
* [CDS Personne Physique](StructureDefinition-cds-personne-physique.md)
* [CDS Personne Prise Charge](StructureDefinition-cds-personne-prise-charge.md)
* [CDS Professionnel](StructureDefinition-cds-professionnel.md)
* [CDS Situation Exercice](StructureDefinition-cds-situation-exercice.md)

### Resource Profiles

* [CDS Bundle Response Recherche Profile](StructureDefinition-cds-bundle-response-recherche.md)
* [CDS Bundle Transaction Creation Profile](StructureDefinition-cds-bundle-transaction-creation.md)
* [CDS Bundle Transaction MAJ Profile](StructureDefinition-cds-bundle-transaction-maj.md)
* [CDS Fr RelatedPerson Profile](StructureDefinition-cds-fr-related-person.md)
* [CDS CareTeam Profile](StructureDefinition-cds-ihe-careteam.md)
* [CDS Organization Profile](StructureDefinition-cds-organization.md)

### Basics

* [CDS-Consommateur-Actor](Basic-CDS-Consommateur-Actor.md)
* [CDS-Createur-Actor](Basic-CDS-Createur-Actor.md)
* [CDS-Gestionnaire-Actor](Basic-CDS-Gestionnaire-Actor.md)

### CapabilityStatements

* [CI-SIS Gestion du Cercle de Soins - Consommateur](CapabilityStatement-CDSConsommateur.md)
* [CI-SIS Gestion du Cercle de Soins - CreateurRestful](CapabilityStatement-CDSCreateurRestful.md)
* [CI-SIS Gestion du Cercle de Soins - CreateurTransaction](CapabilityStatement-CDSCreateurTransaction.md)
* [CI-SIS Gestion du Cercle de Soins - Gestionnaire](CapabilityStatement-CDSGestionnaire.md)

### ImplementationGuides

* [Cercle De Soins](ImplementationGuide-ans.fhir.fr.cds.md)

### SearchParameters

* [CDSCareTeamEnd](SearchParameter-cds-careteam-end.md)
* [CDSCareTeamManagingOrganization](SearchParameter-cds-careteam-managing-organization.md)
* [CDSCareTeamParticipantEnd](SearchParameter-cds-careteam-participant-end.md)
* [CDSCareTeamParticipantStart](SearchParameter-cds-careteam-participant-start.md)
* [CDSCareTeamStart](SearchParameter-cds-careteam-start.md)
* [CDSPatientBirthplace](SearchParameter-cds-patient-birthplace.md)

### Examples

* [cds-bundle-transaction-creation-example (Bundle)](Bundle-cds-bundle-transaction-creation-example.md)
* [Cercle de soins de Mr Jacques Thobois (CareTeam)](CareTeam-cds-careteam-example.md)
* [Cabinet médical CC CC (Organization)](Organization-cds-organization-example.md)
* [cds-patient-example (Patient)](Patient-cds-patient-example.md)
* [cds-relatedperson-example (RelatedPerson)](RelatedPerson-cds-relatedperson-example.md)
