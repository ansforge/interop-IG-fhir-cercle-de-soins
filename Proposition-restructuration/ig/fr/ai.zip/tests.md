# Tests - Cercle De Soins v2.0.1

## Tests

### Solutions de tests

#### Validateurs FHIR

La plateforme de test [EVSClient](https://interop.esante.gouv.fr/evs/default/validator.seam?standard=30) propose un validateur FHIR par profil défini dans ce guide d'implémentation (cf onglet [Ressources de conformité](artifacts.md)).

La documentation de l'outil EVSClient est accessible [ici](https://interop.esante.gouv.fr/gazelle-documentation/EVS-Client/user.html).

#### Guide ANS

Le guide d'implémentation de l'ANS décrit sur [cette page](https://interop.esante.gouv.fr/ig/documentation/tests.html) les différents outils de tests à disposition.

